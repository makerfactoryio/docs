
void displayRGB565(unsigned char *frame, int xres, int yres)
{
    tft.setAddrWindow(1, 1, yres, xres);
    int i = 0;
    for(int x = 0; x < xres; x++)
        for(int y = 0; y < yres; y++)
    {
        i = (y * xres + x) << 1;
        tft.pushColor(frame[i] | (frame[i + 1] << 8));
    } 
}

void testTFT(int xres, int yres) //a small tft test output showing errors on my tft with bright colors
{
    tft.setAddrWindow(1, 1, xres, yres);
    int i = 0;
    for(int y = 0; y < yres; y++)
        for(int x = 0; x < xres; x++)
        tft.pushColor(x | y << 10);
}
